Signature[1] based upon the C14N[2] examples

[1] http://www.w3.org/TR/2000/WD-xmldsig-core-20001012
[2] http://www.w3.org/TR/2000/WD-xml-c14n-20001011

See signature.xml

Included in the directory is each example, along with a
file .c14n which is the raw output of the canonicalization
process.

Merlin Hughes <merlin@baltimore.ie>
Baltimore Technologies, Ltd.

Saturday, October 14, 2000
