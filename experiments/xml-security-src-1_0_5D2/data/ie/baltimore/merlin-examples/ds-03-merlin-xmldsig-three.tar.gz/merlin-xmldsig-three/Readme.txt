The key for the HMAC-SHA1 signatures is "secret".getBytes("ASCII")
which is, in hex, (73 65 63 72 65 74).

Merlin Hughes <merlin@baltimore.ie>
Baltimore Technologies, Ltd.
