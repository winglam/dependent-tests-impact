The signed document is merlin-xmldsig.xml (envelope.dtd).

A version using a stringified XSLT element is merlin-xmldsig-xslt.xml.

The Signature element is:
  document.getDocumentElement().getLastChild().getPreviousSibling()

The output of all phases of C14N and XLS are in the int directory.

Merlin Hughes <merlin@baltimore.ie>
Baltimore Technologies, Ltd.
