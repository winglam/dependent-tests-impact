Signature based upon the examples from
http://www.w3.org/TR/2000/WD-xml-c14n-20000907

After various corrections discussed on
http://lists.w3.org/Archives/Public/w3c-ietf-xmldsig

See signature.xml

Included in the directory is each example, along with a
file .c14n which is the raw output of the canonicalization
process.

Merlin Hughes <merlin@baltimore.ie>
Baltimore Technologies, Ltd.

Wednesday, October 11, 2000
